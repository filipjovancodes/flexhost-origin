const { handler } = require('/Users/filipjovanovic/Projects/test-manual-deployment/my-amplify-app/lambda/s3lambda/index.js'); // Assuming your Lambda function is in index.js

// Invoke the Lambda function
export function testLambda(event) {
    return handler(event)
        .then(response => {
            console.log('Lambda function response:', response);
        })
        .catch(error => {
            console.error('Error invoking Lambda function:', error);
        });
}