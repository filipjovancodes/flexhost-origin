const AWS = require('aws-sdk');
const s3 = new AWS.S3();

exports.handler = async (event) => {
    try {
        console.log('Lambda received event: ', event)

        const requestBody = JSON.parse(event.body);
        
        const params = {
            Bucket: requestBody.bucketName,
            Key: requestBody.fileName,
        };

        // Uploading the file to S3
        const data = await s3.getObject(params).promise();
        console.log(`File received successfully. ${data.Location}`);

        return {
            statusCode: 200,
            headers: buildHeaders(),
            body: JSON.stringify({ 
                message: 'File received successfully', 
                data: data 
            }),
        };
    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            headers: buildHeaders(),
            body: JSON.stringify({ message: 'Error receiving file', error: error.message }),
        };
    }
};

function buildHeaders() {
    return {
        "Access-Control-Allow-Origin": "*", // Allow all origins
        "Access-Control-Allow-Methods": "OPTIONS,GET,POST", // Allowed methods
        "Access-Control-Allow-Headers": "Content-Type", // Allowed headers
    }
}